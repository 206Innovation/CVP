Dillon Equation Final Journal Submission Package

Contents:
- Dillon_Equation_Final_Journal_Manuscript.pdf
- Dillon_Equation_Final_Journal_Manuscript.docx
- Dillon_Equation_Final_Journal_Manuscript.tex
- Dillon_Equation_Final_Cover_Letter.pdf
- Dillon_Equation_Final_Cover_Letter.docx
- Dillon_Equation_Final_Submission_Metadata.pdf
- Dillon_Equation_Final_Submission_Metadata.docx

Notes:
- Internal version/package notes have been removed from the manuscript title and front matter.
- The final manuscript includes a journal-safe Omega-Genesis / Omega Calculus section and a public-review archive appendix.
- The physical claims remain scoped to the curvature-variable propagation framework, local Einstein limit, normalized deviation observable, and falsifiability program.
- Related proof manuscripts, simulations, code, and validation artifacts are treated as public-review context, not as premises required for the Dillon Equation paper.
